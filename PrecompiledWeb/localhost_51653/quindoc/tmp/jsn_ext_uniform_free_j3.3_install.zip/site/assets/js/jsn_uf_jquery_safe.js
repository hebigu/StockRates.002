try { 
		if (typeof(jQuery)=='function')
		{ 
			var JSNUFjQueryBefore = jQuery; 
		}
} catch (e) {}